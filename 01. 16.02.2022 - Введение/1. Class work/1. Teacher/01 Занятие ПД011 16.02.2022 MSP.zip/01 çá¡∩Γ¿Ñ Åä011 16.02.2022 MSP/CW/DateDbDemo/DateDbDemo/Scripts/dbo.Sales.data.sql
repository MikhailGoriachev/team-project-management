SET IDENTITY_INSERT [dbo].[Sales] ON
INSERT INTO [dbo].[Sales] ([Id], [SaleDate], [Cost], [Amount], [IdSeller]) VALUES (1, N'2022-01-10', 100, 1, 1)
INSERT INTO [dbo].[Sales] ([Id], [SaleDate], [Cost], [Amount], [IdSeller]) VALUES (2, N'2022-01-11', 50, 2, 1)
INSERT INTO [dbo].[Sales] ([Id], [SaleDate], [Cost], [Amount], [IdSeller]) VALUES (3, N'2022-01-12', 20, 5, 2)
INSERT INTO [dbo].[Sales] ([Id], [SaleDate], [Cost], [Amount], [IdSeller]) VALUES (5, N'2022-01-13', 10, 3, 2)
INSERT INTO [dbo].[Sales] ([Id], [SaleDate], [Cost], [Amount], [IdSeller]) VALUES (6, N'2022-01-14', 20, 2, 1)
INSERT INTO [dbo].[Sales] ([Id], [SaleDate], [Cost], [Amount], [IdSeller]) VALUES (7, N'2022-01-15', 30, 3, 2)
INSERT INTO [dbo].[Sales] ([Id], [SaleDate], [Cost], [Amount], [IdSeller]) VALUES (8, N'2022-02-01', 10, 2, 3)
INSERT INTO [dbo].[Sales] ([Id], [SaleDate], [Cost], [Amount], [IdSeller]) VALUES (9, N'2022-02-02', 20, 3, 1)
INSERT INTO [dbo].[Sales] ([Id], [SaleDate], [Cost], [Amount], [IdSeller]) VALUES (10, N'2022-02-03', 30, 2, 1)
INSERT INTO [dbo].[Sales] ([Id], [SaleDate], [Cost], [Amount], [IdSeller]) VALUES (11, N'2022-02-04', 30, 5, 2)
SET IDENTITY_INSERT [dbo].[Sales] OFF
